from django.contrib import admin
from .models import VerifationInformation, AppUser
# Register your models here.

admin.site.register(VerifationInformation)
admin.site.register(AppUser)
