from multiprocessing import context
from django.shortcuts import render
from django.views import View
from django.shortcuts import render, redirect
from core import models as AppModel
from django.contrib import messages
from .forms import *
from django.http import HttpResponse
from twilio.rest import Client
import idanalyzer
import datetime
import time
# Create your views here.
import base64
from django.core.files.base import ContentFile
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializer import VerifationSerializer
from twilio.base.exceptions import TwilioRestException
from .forms import NewUserForm
from django.contrib.auth import login
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm, PasswordResetForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from demo import settings
from django.core.mail import send_mail, BadHeaderError


@method_decorator(login_required, name='dispatch')
class dashboard(View):
    template = 'index.html'

    def get(self, request):
        Success = AppModel.VerifationInformation.objects.filter(
            user=request.user,
            status__icontains='TRUE').count()

        failed = AppModel.VerifationInformation.objects.filter(
            user=request.user,
            status__icontains='FALSE').count()

        total_verification = AppModel.VerifationInformation.objects.filter(
            user=request.user)
        context = {'success': Success, 'failed': failed,
                   'total_verification': total_verification}
        return render(request=request, template_name=self.template, context=context)

    def post(self, request):
        # form=forms.AddEmployeeModelForm(request.POST, request.FILES)
        # if form.is_valid():
        #     form.save()
        return render(request=request, template_name=self.template)


@method_decorator(login_required, name='dispatch')
class AgeVerification(View):
    template = 'age_verification.html'
    context = {}

    def get(self, request):
        return render(request=request, template_name=self.template)

    def post(self, request):
        print(request.POST)
        form = AgeVerificationForm(request.POST, request.FILES)
        if form.is_valid():
            print("form is valid")
            a = form.save()
            get_image = AppModel.VerifationInformation.objects.get(pk=a.id)
            image = get_image.image
            print(f"media/{image}")
            path = f"media/{image}"
            print(type(path))
            Age = str(get_image.Dob)

            print("done")
            flag = "true"

            try:

                # Initialize Core API with your api key and region (US/EU)
                coreapi = idanalyzer.CoreAPI(
                    "f99IPiCtAE5y3XMRiq5Wmzu43k2jwVsD", "US")

                # Raise exceptions for API level errors
                coreapi.throw_api_exception(True)

                # enable document authentication using quick module
                coreapi.enable_authentication(True, 'quick')

                # perform scan
                print("before scan")
                response = coreapi.scan(document_primary=path)
                print("after scan")
                # dual-side scan
                # response = coreapi.scan(document_primary="id_front.jpg", document_secondary="id_back.jpg")

                # video biometric verification
                # response = coreapi.scan(document_primary="id_front.jpg", biometric_video="face_video.mp4", biometric_video_passcode="1234")

                # All the information about this ID will be returned in response dictionary
                print(response)

                # Print document holder name
                if response.get('result'):
                    data_result = response['result']
                    print("Hello your name is {} {}".format(
                        data_result['firstName'], data_result['lastName']))

                # Parse document authentication results
                if response.get('authentication'):
                    authentication_result = response['authentication']
                    if authentication_result['score'] > 0.5:
                        print("The document uploaded is authentic")
                        result = response['result']
                        dob = result['dob']
                        status_query = AppModel.VerifationInformation.objects.get(
                            pk=a.id)
                        firatname = status_query.firstname
                        responsefirstname = result['firstName']
                        save_dob = datetime.datetime.strptime(
                            Age, '%Y-%m-%d').strftime('%Y/%m/%d')
                        print(save_dob)
                        print(Age)
                        if dob == save_dob and firatname == responsefirstname:
                            status_query = AppModel.VerifationInformation.objects.get(
                                pk=a.id)
                            status_query.status = "True"
                            status_query.save()
                            context = {"flag": flag}
                            return render(request=request, template_name=self.template, context=context)
                        else:
                            return HttpResponse("Age or Name not matched")

                    elif authentication_result['score'] > 0.3:
                        print("The document uploaded looks little bit suspicious")
                        return HttpResponse("The document uploaded looks little bit suspicious")
                    else:
                        print("The document uploaded is fake")
                        return HttpResponse("The document uploaded is fake")

            except idanalyzer.APIError as e:
                # If API returns an error, catch it
                details = e.args[0]
                print("API error code: {}, message: {}".format(
                    details["code"], details["message"]))
            except Exception as e:
                print(e)

        else:
            print(form.errors)

        return HttpResponse(status=204)


@method_decorator(login_required, name='dispatch')
class PhotoID(View):
    template = 'photo_verification.html'
    context = {}

    def get(self, request):

        return render(request=request, template_name=self.template)

    def post(self, request):
        if request.method == 'POST' and request.POST['phoneno'] != "":
            print(request.POST)
            phone = request.POST.get('intl_phone_number')
            form = VerifationInformationForm(request.POST or None)
            if form.is_valid():
                print("form is valid")
                a = form.save()
                print("-------------------------")
                print(a.id)
            else:
                print(form.errors)

            get_otp = AppModel.VerifationInformation.objects.get(pk=a.id)
            otp = get_otp.otp
            phone = request.POST.get('phoneno')
            print(phone)
            try:
                account_sid = 'ACd6c5c7e6541955854a634cdc068a77b4'
                auth_token = 'cf53a0a6c57cf12cc7294ed04736f988'
                client = Client(account_sid, auth_token)

                message = client.messages.create(
                    body=f'Hi there: Your Moneytranser OTP:{otp}',
                    from_='+14422336391',
                    to=phone
                )

                print(message.sid)
            except TwilioRestException as err:
                return HttpResponse("OTP sendig Failed")

            request.session["id"] = a.id
            return HttpResponse(status=204)

        form = AgeVerificationForm(request.POST, request.FILES)
        if form.is_valid():
            print("form is valid")
            flag = "true"
            a = form.save()
            get_image = AppModel.VerifationInformation.objects.get(pk=a.id)
            image = get_image.image
            print(f"media/{image}")
            path = f"media/{image}"
            print(type(path))

            try:

                # Initialize Core API with your api key and region (US/EU)
                coreapi = idanalyzer.CoreAPI(
                    "f99IPiCtAE5y3XMRiq5Wmzu43k2jwVsD", "US")

                # Raise exceptions for API level errors
                coreapi.throw_api_exception(True)

                # enable document authentication using quick module
                coreapi.enable_authentication(True, 'quick')

                # perform scan
                print("before scan")
                response = coreapi.scan(document_primary=path)
                print("after scan")
                # dual-side scan
                # response = coreapi.scan(document_primary="id_front.jpg", document_secondary="id_back.jpg")

                # video biometric verification
                # response = coreapi.scan(document_primary="id_front.jpg", biometric_video="face_video.mp4", biometric_video_passcode="1234")

                # All the information about this ID will be returned in response dictionary
                print(response)

                # Print document holder name
                if response.get('result'):
                    data_result = response['result']
                    print("Hello your name is {} {}".format(
                        data_result['firstName'], data_result['lastName']))

                # Parse document authentication results
                if response.get('authentication'):
                    authentication_result = response['authentication']
                    if authentication_result['score'] > 0.5:
                        print("The document uploaded is authentic")
                        result = response['result']
                        status_query = AppModel.VerifationInformation.objects.get(
                            pk=a.id)
                        firatname = status_query.firstname
                        responsefirstname = result['firstName']
                        if firatname == responsefirstname:
                            status_query = AppModel.VerifationInformation.objects.get(
                                pk=a.id)
                            status_query.status = "True"
                            status_query.save()
                            context = {"flag": flag}
                            return render(request=request, template_name=self.template, context=context)
                        else:
                            return HttpResponse("Name not matched")

                    elif authentication_result['score'] > 0.3:
                        print("The document uploaded looks little bit suspicious")
                        return HttpResponse("The document uploaded looks little bit suspicious")
                    else:
                        print("The document uploaded is fake")
                        return HttpResponse("The document uploaded is fake")

            except idanalyzer.APIError as e:
                # If API returns an error, catch it
                details = e.args[0]
                print("API error code: {}, message: {}".format(
                    details["code"], details["message"]))
                return HttpResponse("API error code: {}, message: {}".format(details["code"], details["message"]))
            except Exception as e:
                print(e)

        else:
            print(form.errors)
        return HttpResponse(status=204)


@method_decorator(login_required, name='dispatch')
class PhoneNUM(View):
    template = 'phone_verifictation.html'
    context = {}

    def get(self, request):
        print("---------i am here")
        return render(request=request, template_name=self.template)

    def post(self, request):

        print(request.POST)
        phone = request.POST.get('intl_phone_number')
        form = VerifationInformationForm(request.POST or None)
        if form.is_valid():
            print("form is valid")
            a = form.save()
            print("-------------------------")
            print(a.id)
        else:
            print(form.errors)

        get_otp = AppModel.VerifationInformation.objects.get(pk=a.id)
        otp = get_otp.otp
        phone = request.POST.get('phoneno')
        print(phone)
        try:
            account_sid = 'ACd6c5c7e6541955854a634cdc068a77b4'
            auth_token = 'cf53a0a6c57cf12cc7294ed04736f988'
            client = Client(account_sid, auth_token)

            message = client.messages.create(
                body=f'Hi there: Your Moneytranser OTP:{otp}',
                from_='+14422336391',
                to=phone
            )

            print(message.sid)
        except TwilioRestException as err:
            return HttpResponse("OTP sendig Failed")
        return HttpResponse(status=204)


@method_decorator(login_required, name='dispatch')
class ApiIntegration(View):
    template = 'api_integration.html'
    context = {}

    def get(self, request):
        return render(request=request, template_name=self.template)

    def post(self, request):
        # form=forms.AddEmployeeModelForm(request.POST, request.FILES)
        # if form.is_valid():
        #     form.save()
        return render(request=request, template_name=self.template)


@method_decorator(login_required, name='dispatch')
def otp(request):
    print("i am here")
    if request.method == 'POST':
        print(request.POST)
        print("i am also here")
        first = request.POST['1']
        second = request.POST['2']
        third = request.POST['3']
        forth = request.POST['4']
        fifth = request.POST['5']
        sixth = request.POST['6']
        otp = first+second+third+forth+fifth+sixth

        if AppModel.VerifationInformation.objects.filter(otp__icontains=otp):
            return HttpResponse(status=204)
        else:
            return HttpResponse("OTP Authentication failed...!")

    return HttpResponse(status=501)


@method_decorator(login_required, name='dispatch')
def otp_photo(request):
    print("i am here")
    if request.method == 'POST':
        print(request.POST)
        print("i am also here")
        first = request.POST['1']
        second = request.POST['2']
        third = request.POST['3']
        forth = request.POST['4']
        fifth = request.POST['5']
        sixth = request.POST['6']
        otp = first+second+third+forth+fifth+sixth

        if AppModel.VerifationInformation.objects.filter(otp__icontains=otp):
            return redirect('takephoto')
        else:
            return HttpResponse("OTP Authentication failed...!")

    return HttpResponse(status=501)


@method_decorator(login_required, name='dispatch')
class Feature(View):
    template = 'photo_verification.html'
    context = {}

    def get(self, request):
        return render(request=request, template_name=self.template)

    def post(self, request):
        # form=forms.AddEmployeeModelForm(request.POST, request.FILES)
        # if form.is_valid():
        #     form.save()
        return render(request=request, template_name=self.template)


@method_decorator(login_required, name='dispatch')
class FAQ(View):
    template = 'photo_verification.html'
    context = {}

    def get(self, request):
        return render(request=request, template_name=self.template)

    def post(self, request):
        # form=forms.AddEmployeeModelForm(request.POST, request.FILES)
        # if form.is_valid():
        #     form.save()
        return render(request=request, template_name=self.template)


@method_decorator(login_required, name='dispatch')
class BlOG(View):
    template = 'photo_verification.html'
    context = {}

    def get(self, request):
        return render(request=request, template_name=self.template)

    def post(self, request):
        # form=forms.AddEmployeeModelForm(request.POST, request.FILES)
        # if form.is_valid():
        #     form.save()
        return render(request=request, template_name=self.template)


@method_decorator(login_required, name='dispatch')
class support(View):
    template = 'photo_verification.html'
    context = {}

    def get(self, request):
        return render(request=request, template_name=self.template)

    def post(self, request):
        # form=forms.AddEmployeeModelForm(request.POST, request.FILES)
        # if form.is_valid():
        #     form.save()
        return render(request=request, template_name=self.template)


@method_decorator(login_required, name='dispatch')
class website(View):
    template = 'home.html'
    context = {}

    def get(self, request):
        return redirect("dashboard")
    # def post(self,request):
    #     # form=forms.AddEmployeeModelForm(request.POST, request.FILES)
    #     # if form.is_valid():
    #     #     form.save()
    #     return render(request=request,template_name=self.template)


@method_decorator(login_required, name='dispatch')
def takephoto(request):
    if 'id' in request.session:
        id = request.session['id']
        print(id)
    return render(request, "Take_photo.html")


@method_decorator(login_required, name='dispatch')
class takephoto(View):
    template = 'Take_photo.html'
    context = {}

    def get(self, request):
        return render(request=request, template_name=self.template)

    def post(self, request):
        image = request.POST['image']
        format, imgstr = image.split(';base64,')
        print("format", format)
        ext = format.split('/')[-1]

        data = ContentFile(base64.b64decode(imgstr), name='temp.' + ext)

        if 'id' in request.session:
            id = request.session['id']
            print(id)
            get_image = AppModel.VerifationInformation.objects.get(pk=id)
            get_image.image = data
            get_image.save()
            send_image = get_image.image
            path = f"media/{send_image}"
            print(path)
            try:

                # Initialize Core API with your api key and region (US/EU)
                coreapi = idanalyzer.CoreAPI(
                    "f99IPiCtAE5y3XMRiq5Wmzu43k2jwVsD", "US")

                # Raise exceptions for API level errors
                coreapi.throw_api_exception(True)

                # enable document authentication using quick module
                coreapi.enable_authentication(True, 'quick')

                # perform scan
                print("before scan")
                response = coreapi.scan(document_primary=path)
                print("after scan")
                # dual-side scan
                # response = coreapi.scan(document_primary="id_front.jpg", document_secondary="id_back.jpg")

                # video biometric verification
                # response = coreapi.scan(document_primary="id_front.jpg", biometric_video="face_video.mp4", biometric_video_passcode="1234")

                # All the information about this ID will be returned in response dictionary
                print(response)

                # Print document holder name
                if response.get('result'):
                    data_result = response['result']
                    print("Hello your name is {} {}".format(
                        data_result['firstName'], data_result['lastName']))

                # Parse document authentication results
                if response.get('authentication'):
                    authentication_result = response['authentication']
                    if authentication_result['score'] > 0.5:
                        # print("The document uploaded is authentic")
                        # result=response['result']
                        # dob=result['dob']

                        # save_dob=datetime.datetime.strptime(Age, '%Y-%m-%d').strftime('%Y/%m/%d')

                        # if dob == save_dob:
                        #     status_query = VerifationInformation.objects.get(pk=a.id)
                        #     status_query.status = "True"
                        #     status_query.save()
                        #     context={"flag":flag}
                        return render(request=request, template_name=self.template)
                        # else:
                        #     return HttpResponse("Age not matched")

                    elif authentication_result['score'] > 0.3:
                        print("The document uploaded looks little bit suspicious")
                        return HttpResponse("The document uploaded looks little bit suspicious")
                    else:
                        print("The document uploaded is fake")
                        return HttpResponse("The document uploaded is fake")

            except idanalyzer.APIError as e:
                # If API returns an error, catch it
                details = e.args[0]
                print("API error code: {}, message: {}".format(
                    details["code"], details["message"]))
                return HttpResponse("API error code: {}, message: {}".format(details["code"], details["message"]))
            except Exception as e:
                print(e)

        return render(request=request, template_name=self.template)


@method_decorator(login_required, name='dispatch')
class Apiverification(APIView):
    """
    List all snippets, or create a new snippet.
    """

    def get(self, request, format=None):
        snippets = AppModel.VerifationInformation.objects.filter(
            user=request.user)
        serializer = VerifationSerializer(snippets, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = VerifationSerializer(data=request.data)
        if serializer.is_valid():
            a = serializer.save()
            print(a.id)
            get_image = models.VerifationInformation.objects.get(pk=a.id)
            image = get_image.image
            print(f"media/{image}")
            path = f"media/{image}"
            print(type(path))

            try:

                # Initialize Core API with your api key and region (US/EU)
                coreapi = idanalyzer.CoreAPI(
                    "f99IPiCtAE5y3XMRiq5Wmzu43k2jwVsD", "US")

                # Raise exceptions for API level errors
                coreapi.throw_api_exception(True)

                # enable document authentication using quick module
                coreapi.enable_authentication(True, 'quick')

                # perform scan
                print("before scan")
                response = coreapi.scan(document_primary=path)
                print("after scan")
                # dual-side scan
                # response = coreapi.scan(document_primary="id_front.jpg", document_secondary="id_back.jpg")

                # video biometric verification
                # response = coreapi.scan(document_primary="id_front.jpg", biometric_video="face_video.mp4", biometric_video_passcode="1234")

                # All the information about this ID will be returned in response dictionary
                print(response)

                # Print document holder name
                if response.get('result'):
                    data_result = response['result']
                    print("Hello your name is {} {}".format(
                        data_result['firstName'], data_result['lastName']))

                # Parse document authentication results
                if response.get('authentication'):
                    authentication_result = response['authentication']
                    if authentication_result['score'] > 0.5:
                        print("The document uploaded is authentic")
                        status_query = AppModel.VerifationInformation.objects.get(
                            pk=a.id)
                        status_query.status = "True"
                        status_query.Verification_type = "PHOTO"
                        status_query.save()
                        return Response("Verification Successfull")

                    elif authentication_result['score'] > 0.3:
                        status_query = AppModel.VerifationInformation.objects.get(
                            pk=a.id)
                        status_query.status = "False"
                        status_query.Verification_type = "PHOTO"
                        status_query.save()
                        print("The document uploaded looks little bit suspicious")
                        return Response("he document uploaded looks little bit suspicious")
                    else:
                        status_query = AppModel.VerifationInformation.objects.get(
                            pk=a.id)
                        status_query.status = "False"
                        status_query.Verification_type = "PHOTO"
                        status_query.save()
                        print("The document uploaded is fake")
                        return Response("The document uploaded is fake")

            except idanalyzer.APIError as e:
                # If API returns an error, catch it
                details = e.args[0]
                print("API error code: {}, message: {}".format(
                    details["code"], details["message"]))
                return Response("API error code: {}, message: {}".format(details["code"], details["message"]))
            except Exception as e:
                print(e)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class password_reset_request(View):
    template_name = "password/password_reset.html"
    context = {}

    def get(self, request):
        context = self.context
        password_reset_form = PasswordResetForm()
        context["password_reset_form"] = password_reset_form
        return render(request=request, template_name=self.template_name, context=context)

    def post(self, request):
        password_reset_form = PasswordResetForm(request.POST)
        if password_reset_form.is_valid():
            data = password_reset_form.cleaned_data['email']
            associated_users = User.objects.filter(Q(email=data))
            if associated_users.exists():
                for user in associated_users:
                    subject = "Password Reset Requested"
                    email_template_name = "password/password_reset_email.txt"
                    c = {
                        "email": user.email,
                        'domain': settings.DOMAIN,
                        'site_name': settings.SITENAME,
                        "uid": urlsafe_base64_encode(force_bytes(user.pk)),
                        "user": user,
                        'token': default_token_generator.make_token(user)
                    }
                    email = render_to_string(email_template_name, c)
                    try:
                        send_mail(subject, email, settings.EMAIL_HOST_USER, [
                                  user.email], fail_silently=False)
                    except BadHeaderError:
                        return HttpResponse('Invalid header found.')
                    return redirect("/password_reset/done/")


class register_request(View):
    template_name = "authentication.html"
    context = {}

    def get(self, request):
        # form = NewUserForm()
        # context = self.context
        # context["register_form"] = form
        return render(request=request, template_name=self.template_name)

    def post(self, request):
        new = request.POST.copy()
        new['username'] = new['email']
        form = NewUserForm(new)
        if form.is_valid():
            user = form.save()
            user.save()
        else:
            print(form.errors)
        context = self.context
        context["register_form"] = form
        return render(request=request, template_name=self.template_name)


def activate(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        return render(request, 'password/acc_activated.html')
    else:
        return HttpResponse('Activation link is invalid!')


class login_request(View):
    template_name = "signin.html"
    context = {}

    def get(self, request):
        context = self.context
        form = AuthenticationForm()
        context["login_form"] = form
        return render(request=request, template_name=self.template_name, context=context)

    def post(self, request):
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active == True:
                    login(request, user)
                    return redirect("dashboard")
                else:
                    messages.error(request, "Your account is not active.")
        else:
            if AppModel.AppUser.objects.filter(username=request.POST['username']).exists():
                messages.error(request, "Invalid password.")
            else:
                messages.error(request, "Invalid username.")
        context = self.context
        context["login_form"] = form
        return render(request=request, template_name=self.template_name, context=context)


class logout_request(View):
    def get(self, request):
        logout(request)
        messages.info(request, "You have successfully logged out.")
        return redirect("/")


class Index(View):
    template = "home.html"

    def get(self, request):
        return render(request, self.template)
