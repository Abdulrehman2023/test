from time import time
from unittest.util import _MAX_LENGTH
from django.db import models
import random
from django.contrib.auth.models import AbstractUser
# Create your models here.
import datetime


class VerifationType(models.TextChoices):
    phone = 'PHONE', 'phone'
    age = 'AGE', 'age'
    photo = 'PHOTO', 'photo'


class status(models.TextChoices):
    true = 'True', 'true'
    false = 'False', 'false'


class AppUser(AbstractUser):
    email = models.EmailField(unique=True, null=False)
    phone = models.CharField(max_length=20, blank=True, null=True)
    bussinessname = models.CharField(max_length=40, blank=True, null=True)
    country = models.CharField(max_length=40, blank=True, null=True)
    state = models.CharField(max_length=40, blank=True, null=True)
    termsandcondition = models.BooleanField(default=False)
    Billing_firstname = models.CharField(max_length=40, blank=True, null=True)
    Billing_lastname = models.CharField(max_length=40, blank=True, null=True)
    Billing_country = models.CharField(max_length=40, blank=True, null=True)
    Billing_address = models.CharField(max_length=40, blank=True, null=True)
    Billing_city = models.CharField(max_length=40, blank=True, null=True)
    Billing_state = models.CharField(max_length=40, blank=True, null=True)
    Billing_zip = models.IntegerField(blank=True, null=True)
    Billing_date = models.DateField(default=datetime.date.today)
    Billing_CardNumber = models.IntegerField(blank=True, null=True)
    Billing_cvv = models.IntegerField(default=0)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["username"]

    def __str__(self):
        return self.email


class VerifationInformation(models.Model):
    user = models.ForeignKey(AppUser, on_delete=models.CASCADE)
    otp = models.CharField(max_length=6, default=str(
        random.randint(100000, 999999)))
    firstname = models.CharField(max_length=150, blank=True)
    lastname = models.CharField(max_length=150, blank=True)
    Country = models.CharField(max_length=150, blank=True)
    city = models.CharField(max_length=150, blank=True)
    Address = models.CharField(max_length=150, blank=True)
    state = models.CharField(max_length=150, blank=True)
    zip = models.IntegerField()
    used_for_purpose = models.CharField(max_length=150, blank=True)
    Verification_type = models.CharField(
        max_length=50, choices=VerifationType.choices)
    date = models.DateField(auto_now=True)
    time = models.TimeField(auto_now=True)
    status = models.CharField(max_length=50, choices=status.choices)
    image = models.ImageField(upload_to="profiles/")
    Dob = models.DateField(blank=True, null=True)

    def __str__(self):
        return self.firstname
