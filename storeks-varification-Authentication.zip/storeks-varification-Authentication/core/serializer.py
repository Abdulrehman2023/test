from dataclasses import field
from rest_framework.serializers import ModelSerializer
from .models import VerifationInformation

class VerifationSerializer(ModelSerializer):
    class Meta:
        model = VerifationInformation
        fields = "firstname","lastname","Country","city","Address","state","zip","image"