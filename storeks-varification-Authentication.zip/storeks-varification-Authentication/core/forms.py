from .models import *

from django.forms import ModelForm

from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class VerifationInformationForm(ModelForm):
    class Meta:
        model = VerifationInformation
        fields = "user","firstname", "lastname", "Country", "city", "Address", "state", "zip", "Verification_type", "status"


class AgeVerificationForm(ModelForm):
    class Meta:
        model = VerifationInformation
        fields = "user","firstname", "lastname", "Country", "city", "Address", "state", "zip", "Verification_type", "status", "image", "Dob"


class NewUserForm(UserCreationForm):
    class Meta:
        model = AppUser
        fields = ["username", "email", "phone", "first_name", "last_name", "bussinessname", "country", "state", "termsandcondition", "termsandcondition", "Billing_firstname", "Billing_lastname",
                  "Billing_country", "Billing_address", "Billing_city", "Billing_city", "Billing_state", "Billing_zip", "Billing_date", "Billing_date", "Billing_cvv", "password1", "password2"]
