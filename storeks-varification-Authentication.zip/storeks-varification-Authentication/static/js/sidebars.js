/* global bootstrap: false */
(() => {
  'use strict'
  const tooltipTriggerList = Array.from(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  tooltipTriggerList.forEach(tooltipTriggerEl => {
    new bootstrap.Tooltip(tooltipTriggerEl)
  })
})()

const heading = document.getElementById("main_heading");
// const heading = document.querySelector('#main_heading');
const btn = document.getElementById('tooglebtn');
console.log(heading);
btn.addEventListener('click', (e)=>{
  main_heading.classList.toggle('hidden');
}); 
