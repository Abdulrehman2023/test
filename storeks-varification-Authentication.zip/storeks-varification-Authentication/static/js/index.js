// js for moultiple inputs
$(document).ready(function(){
    
    var multipleCancelButton = new Choices('#choices-multiple-remove-button', {
       removeItemButton: true,
       maxItemCount:10,
       searchResultLimit:10,
       renderChoiceLimit:10
     }); 
  });