from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from core import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.Index.as_view(), name="index"),
    path('dashboard/', views.dashboard.as_view(), name="dashboard"),
    path('AgeVerification/', views.AgeVerification.as_view(), name="AgeVerification"),
    path('PhotoID/', views.PhotoID.as_view(), name="PhotoID"),
    path('PhoneNUM/', views.PhoneNUM.as_view(), name="PhoneNUM"),
    path('ApiIntegration/', views.ApiIntegration.as_view(), name="ApiIntegration"),
    path('otp/', views.otp, name="otp"),
    path('takephoto/', views.takephoto.as_view(), name="takephoto"),
    path('otp_photo/', views.otp_photo, name="otp_photo"),
    path('Apiverification/', views.Apiverification.as_view(), name="Apiverification"),
    # path('', views.Apiverification.as_view(), name="Apiverification"),
    path('register/', views.register_request.as_view(), name="register"),
    path('login', views.login_request.as_view(), name="login"),
    path('logout', views.logout_request.as_view(), name="logout"),
    path("password_reset", views.password_reset_request.as_view(),
         name="password_reset"),
    path(
        r'^activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$', views.activate, name='activate'),

]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL,
                          document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
